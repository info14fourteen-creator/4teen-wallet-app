# 4teen-wallet-app — OPEN TODO SURFACE

Generated: 2026-06-04T10:48:41.659Z
Repository: info14fourteen-creator/4teen-wallet-app
Branch: main
Last commit: bf10c666bf830e40f23b83a042aac7ce5bce746c
Short commit: bf10c66
Commit subject: Allow daily blog workflow OIDC
Commit author: info14fourteen-creator
Commit date: 2026-06-04T15:48:27+05:00

## TODO markers (TODO, FIXME, HACK, XXX)

- TODO :: scripts/build-wallet-ai-bundles.mjs:168 :: const TODO_LIMIT = 200;
- TODO :: scripts/build-wallet-ai-bundles.mjs:169 :: const TODO_PATTERNS = ["TODO", "FIXME", "HACK", "XXX"];
- TODO :: scripts/build-wallet-ai-bundles.mjs:359 :: if (results.length >= TODO_LIMIT) break;
- TODO :: scripts/build-wallet-ai-bundles.mjs:368 :: const matched = TODO_PATTERNS.find((pattern) => line.includes(pattern));
- TODO :: scripts/build-wallet-ai-bundles.mjs:378 :: if (results.length >= TODO_LIMIT) break;
- TODO :: scripts/build-wallet-ai-bundles.mjs:516 :: lines.push("- 10_OPEN_TODO_SURFACE.md");
- TODO :: scripts/build-wallet-ai-bundles.mjs:639 :: lines.push(`# ${REPO_NAME} — OPEN TODO SURFACE`);
- TODO :: scripts/build-wallet-ai-bundles.mjs:643 :: lines.push(`## TODO markers (${TODO_PATTERNS.join(", ")})`);
- TODO :: scripts/build-wallet-ai-bundles.mjs:724 :: path.join(repoDir, "10_OPEN_TODO_SURFACE.md"),
- TODO :: scripts/build-wallet-ai-bundles.mjs:751 :: "10_OPEN_TODO_SURFACE.md"
